using System;

namespace buffteks.Models
{
    public class Client
    {
        //project list
        public int ProjectList{get; set;}
        //id
        public int ProjectID{get; set;}
        //first name
        public string FName{get; set;}
        //last name
        public string LName{get; set;}
        //phone
        public int Phone{get; set;}
        //email
        public string Email{get; set;}
        //organization
        public string organization{get; set;}
    }
    
}