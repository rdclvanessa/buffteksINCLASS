using System;

namespace buffteks.Models
{
    public class Students
    {
        //PK
        public int StudentID{get; set;}
        //first name
        public string FName{get; set;}
        //last name
        public string LName{get; set;}
        //phone
        public int Phone{get; set;}
        //email
        public string Email{get; set;}
        //role
        public string Role{get; set;}
    }
}