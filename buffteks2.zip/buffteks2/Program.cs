﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace buffteks2
{
    class Program
    {
        static void Main(string[] args)
        {

            using(var db = new AppDbContext())
            {
                try 
                {
                //db.Database.EnsureDeleted();
                db.Database.EnsureCreated();

                if(!db.Students.Any())
                {
                List<Student> students = new List<Student>()
                {
               new Student()
                {
                    FName = "Jane",
                    LName = "Doe",
                    Phone = "555-555-5555",
                    Email = "JaneD@wtamu.edu",
                    Role = "Junior"
                },
                new Student()
                {
                    FName = "Jeff",
                    LName = "Babb",
                    Phone = "123-555-1234",
                    Email = "asdf@asdf.cds",
                    Role = "Sophmore"
                },
                
                };
                db.Students.AddRange(students);

                db.SaveChanges();
                }
                else
                {
                    var students = db.Students.ToList();
                    foreach(Student s in students)
                    {
                        Console.WriteLine(s);
                    }
                }

                if(!db.Clients.Any())
                {
                List<Client> clients = new List<Client>()
                {
               new Client()
                {
                    ClientId = 1,
                    FName = "Vanessa",
                    LName = "Valen",
                    Phone = "555-555-5555"
                },

                new Client()
                {
                    ClientId = 2,
                    FName = "Cq",
                    LName = "gu",
                    Phone = "599999955"
                },

                };

                db.Clients.AddRange(clients);

                db.SaveChanges();
                }
                else
                {
                    var clients = db.Clients.ToList();
                    foreach(Client c in clients)
                    {
                        Console.WriteLine(c);
                    }
                }
                }

                catch(Exception exp)
                {
                    Console.WriteLine(exp.Message);
                }
            }
        }
    }
}
